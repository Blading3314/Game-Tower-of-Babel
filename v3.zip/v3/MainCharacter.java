import greenfoot.*;

public class MainCharacter extends Actor
{
    private int ySpeed = 0;
    private boolean onGround = false;

    public void act()
    {
        checkKeys();
        applyGravity();
    }

    private void checkKeys()
    {
        if (Greenfoot.isKeyDown("left"))
            move(-3);
        if (Greenfoot.isKeyDown("right"))
            move(3);
        if (Greenfoot.isKeyDown("space") && onGround)
        {
            ySpeed = -10;
            onGround = false;
        }
    }

    private void applyGravity()
    {
        setLocation(getX(), getY() + ySpeed);
        ySpeed++;
        if (getY() > 350) // crude ground check
        {
            setLocation(getX(), 350);
            ySpeed = 0;
            onGround = true;
        }
    }
}