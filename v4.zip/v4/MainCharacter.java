import greenfoot.*;

public class MainCharacter extends Actor
{
    private int ySpeed = 0;
    private boolean onGround = false;
    private GreenfootImage[] runFrames = new GreenfootImage[3];
    private int frame = 0;
    private int animationDelay = 5;  
    private int delayCount = 0;
    private boolean onLadder = false;
    public MainCharacter() {
        for (int i = 0; i < runFrames.length; i++) {
            runFrames[i] = new GreenfootImage("run" + (i + 1) + ".png");
        }
        setImage(runFrames[0]);
    }
    
    public void act()
    {
        applyGravity();
        checkKeys();
        checkPlatform();
    }
    
    private void climbLadder()
    {
    if (Greenfoot.isKeyDown("w")) {
        setLocation(getX(), getY() - 3);
    }
    if (Greenfoot.isKeyDown("s")) {
        setLocation(getX(), getY() + 3);
    }
    setImage(runFrames[0]); 
    }
    
    private void animateRun() {
        delayCount++;
        if (delayCount >= animationDelay) {
            delayCount = 0;
            frame = (frame + 1) % runFrames.length;
            setImage(runFrames[frame]);
        }
    } 
   
    private void checkKeys()
    { 
    
      boolean isMoving = false;

        if (Greenfoot.isKeyDown("a")) {
        move(-3);
        isMoving = true;
      }
        if (Greenfoot.isKeyDown("d")) {
        move(3);
        isMoving = true;
      }

        if (Greenfoot.isKeyDown("space") && onGround)
      {
        ySpeed = -12;
        onGround = false;
      }

        if (isMoving) {
        animateRun();
      }   
        else {
        setImage(runFrames[0]); // standing frame
        frame = 0; // reset animation frame
        delayCount = 0;
    }
    
    } 

    private void applyGravity()
    {
        setLocation(getX(), getY() + ySpeed);
        ySpeed++;
        Actor platform = getOneObjectAtOffset(0, getImage().getHeight()/2 + 5, InvisiblePlatform.class);
        if (platform != null && ySpeed >= 0) {
      setLocation(getX(), platform.getY() - getImage().getHeight()/2);
       ySpeed = 0;
       onGround = true;
     } else if (getY() > 400) { // fallback floor
       setLocation(getX(), 400);
       ySpeed = 0;
       onGround = true;
       } else {
      onGround = false;
       }
    }
    
    private void checkPlatform()
    {
    Actor platform = getOneObjectAtOffset(0, getImage().getHeight()/2 + 5, InvisiblePlatform.class);
    if (platform != null && ySpeed >= 0) {
        setLocation(getX(), platform.getY() - getImage().getHeight()/2);
        ySpeed = 0;
        onGround = true;
    } else if (getY() > 400) { // crude floor
        setLocation(getX(), 400);
        ySpeed = 0;
        onGround = true;
    } else {
        onGround = false;
    }
    }
}