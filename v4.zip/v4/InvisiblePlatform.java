import greenfoot.*;

public class InvisiblePlatform extends Actor
{
    public InvisiblePlatform() {
        getImage().clear(); 
    }
}