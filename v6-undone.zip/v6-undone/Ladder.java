import greenfoot.*;

public class Ladder extends Actor {
    public Ladder() {
        GreenfootImage img = new GreenfootImage(20, 60);  // Width x Height
        img.setColor(Color.ORANGE);
        img.fill();
        setImage(img);
    }
}
