import greenfoot.*;

public class WinZone extends Actor {
    public WinZone() {
        GreenfootImage img = new GreenfootImage(100, 20);
        img.setColor(Color.GREEN);
        img.fill();
        setImage(img);
    }
}