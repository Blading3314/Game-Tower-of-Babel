import greenfoot.*;

public class FallingObstacle extends Actor {
    private int speed = 3;

    public void act() {
        setLocation(getX(), getY() + speed);
        if (getY() > getWorld().getHeight()) {
            getWorld().removeObject(this);
        }

        if (isTouching(MainCharacter.class)) {
            Greenfoot.setWorld(new GameOver());
        }
    }
}