import greenfoot.*;

public class GameOver extends World {
    public GameOver() {
        super(600, 400, 1);
        showText("Game Over", getWidth() / 2, getHeight() / 2 - 20);
        prepare();
    }

    private void prepare() {
        addObject(new RetryButton(), getWidth() / 2, getHeight() / 2 + 20);
    }
}
