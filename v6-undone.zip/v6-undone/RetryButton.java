import greenfoot.*;

public class RetryButton extends Actor {
    public RetryButton() {
        GreenfootImage img = new GreenfootImage("RETRY?", 30, Color.WHITE, Color.BLACK);
        setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level_1());  // Or Level_2 / MainScreen etc.
        }
    }
}
