import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WelcomeScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WelcomeScreen extends World
{
    double timeWelcomeScreenCreation = System.currentTimeMillis();

    public WelcomeScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(460, 460, 1); 
    
        showText("Press Space Bar or wait 5 seconds", getWidth()/2, 20);

    }

    public void act()
    {
       
        if (Greenfoot.isKeyDown("space"))
        {
            Greenfoot.setWorld(new MainScreen()); 

        }

        if (System.currentTimeMillis() >= (timeWelcomeScreenCreation + (5 * 1000)))
        {
            Greenfoot.setWorld(new MainScreen()); 
        }
    }
}
