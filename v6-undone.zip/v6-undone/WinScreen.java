import greenfoot.*;

public class WinScreen extends World {
    public WinScreen() {
        super(600, 400, 1);
        showText("Level Completed!", getWidth()/2, getHeight()/2);

        Greenfoot.setWorld(new Level_2());  // Or next appropriate level
    }
}