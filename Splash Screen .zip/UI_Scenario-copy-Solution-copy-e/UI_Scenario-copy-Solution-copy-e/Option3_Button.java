import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Option3_Button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Option3_Button extends Actor
{
    /**
     * Act - do whatever the Option3_Button wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if (Greenfoot.mouseMoved(this))
        {
            setImage("Option3_Updated_HighlightedEdges.png");
        }
        if (Greenfoot.mouseMoved(getWorld()))
        {
            setImage("Option3_Updated.png");
        }
        if (Greenfoot.mouseClicked(this))
        {

            Display display = new Display();
            getWorld().addObject(display , 280, 500);
         
        }
    }
    }

