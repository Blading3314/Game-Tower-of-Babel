import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Option2_Button here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Option2_Button extends Actor
{
    /**
     * Act - do whatever the Option2_Button wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if (Greenfoot.mouseMoved(this))
        {
            setImage("Option2_Updated_HighlightedEdges.png");
        }
        if (Greenfoot.mouseMoved(getWorld()))
        {
            setImage("Option2_Updated.png");
        }
        if (Greenfoot.mouseClicked(this))
        {

            Display display = new Display();
            getWorld().addObject(display , 280, 500);
        }
    }
    }

